'''
This is an AIMA-Python-based solution for the 8-puzzle problem.

- The states are represented a 1D strings of the form '012345678'. The '0' indicates the space. 
The first three numbers of the tiles on the top row, and so forth.

- The actions are represented as single characters: 'u' for up (that is, move the tile "above" the 
empty space down so as to "move" the space "up"); 'd' for down; 'r' for right and 'l' for left. 

@author: kvlinden
@version 31jan2013

@modified-by: trbandara
'''

from search import Problem, astar_search
import time

class EightPuzzle(Problem):
    '''This is an AIMA Problem sub-class that implements the traditional 8 puzzle.'''
    
    def __init__(self, initial, goal):
        '''This method initializes a standard AIMA search problem for the 8 puzzle.'''
        self.initial = initial
        self.goal = goal
        
    def actions(self, state):
        # TODO: Implement a proper actions() method here.
        return []
    
    def result(self, state, action):
        # TODO: Implement a proper result() method here.
        pass
    
    def goal_test(self, state):
        '''This method determines if the given state is a goal state.'''
        return state == self.goal
    
    def h(self, node):
        '''This calls the chosen heuristic.'''
        return self.h_disabled(node);
    
    def h_disabled(self, node):
        '''This version of h() is disabled (but still admissible because it always underestimates everything).'''
        return 0
    
    def h_mismatched_tiles(self, node):
        pass
    
    def h_manhattan_distance(self, node):
        pass
    
    def swap(self, state, x, y):
        '''This method swaps the tile values in the two given state coordinates.'''
        result = state.replace(state[x], "*")
        result = result.replace(state[y], state[x])
        return result.replace("*", state[y])

            
goal_state = "012345678"
initial_state = "012345678"

p = EightPuzzle(initial_state, goal_state)

time1 = time.time()
solution = astar_search(p).solution()
time2 = time.time()
print ("solution: " + str(solution))
print ("steps: " + str(len(solution)))
print ("time: %0.3f seconds" % (time2 - time1))


